This project can be compiled against LUFA-140928. Put it in the Lufa/Projects folder and run make (assuming you have crosspack or winavr, etc).

http://www.github.com/abcminiuser/lufa/archive/LUFA-140928.zip