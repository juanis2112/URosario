dfu-programmer-x.x.x.tar.gz contains the source tree for this project.
Download this to build and install on a Linux/Unix/Mac system.

dfu-programmer-win-x.x.x.zip contains the pre-compiled Windows executable
and the USB drivers for use with Atmel chips in DFU bootloader mode.

The Windows executable does not need any installation or setup. Just
extract the executable and run it.

The Windows driver can be installed when prompted by Windows when a DFU
device is attached. Do not let Windows search for a driver; specify
the path to search for a driver and point it to the .inf file.
